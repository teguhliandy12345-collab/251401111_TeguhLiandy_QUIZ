# To-Do List React.js

Aplikasi To-Do List frontend menggunakan React.js dan Vite. Data masih menggunakan dummy data di dalam `src/App.jsx` dan dikelola dengan React State, sesuai ketentuan kuis.

## Fitur
- Menampilkan daftar tugas.
- Melihat detail tugas.
- Menambahkan tugas baru.
- Memperbarui tugas.
- Menghapus tugas dengan konfirmasi.
- Pencarian judul dan filter status.
- Ringkasan jumlah seluruh tugas, tugas dalam proses, dan tugas selesai.
- Tampilan responsif untuk desktop dan ponsel.

## Struktur data tugas
Setiap tugas memiliki atribut:
- `id`: identitas unik.
- `title`: judul tugas.
- `description`: deskripsi tugas.
- `priority`: tingkat prioritas (`low`, `medium`, `high`).
- `deadline`: batas waktu penyelesaian.
- `status`: status pengerjaan (`in progress`, `done`).

## Cara menjalankan
Pastikan Node.js sudah terpasang.

1. Ekstrak file ZIP.
2. Buka folder `todo-list-react` di Visual Studio Code.
3. Buka Terminal, lalu jalankan:

```bash
npm install
npm run dev
```

4. Buka alamat lokal yang muncul di terminal, biasanya `http://localhost:5173`.

## Build untuk pengecekan

```bash
npm run build
```

## Screenshot
Setelah aplikasi dijalankan, ambil screenshot tampilan aplikasi dan tambahkan ke folder proyek. Masukkan gambar ke bagian ini, misalnya:

`![Tampilan aplikasi](./screenshot.png)`

## Catatan
Aplikasi ini hanya mengerjakan frontend. Tidak ada backend atau pemanggilan REST API, karena endpoint pada soal hanya menjadi referensi untuk pertemuan berikutnya.
