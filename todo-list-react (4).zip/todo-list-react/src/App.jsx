import { useMemo, useState } from "react";

const initialTodos = [
  {
    id: 1,
    title: "Mengerjakan Proyek Computer Vision",
    description: "Menyelesaikan proyek akhir computer vision tentang deteksi penggunaan helm.",
    priority: "high",
    deadline: "2026-11-28",
    status: "in progress",
  },
  {
    id: 2,
    title: "Mempelajari Dasar Database",
    description: "Mengulang materi SQL, SELECT, WHERE, dan JOIN.",
    priority: "low",
    deadline: "2026-11-29",
    status: "in progress",
  },
  {
    id: 3,
    title: "Membuat Website Portfolio",
    description: "Membuat halaman portfolio sederhana menggunakan HTML, CSS, dan React.",
    priority: "medium",
    deadline: "2026-12-02",
    status: "in progress",
  },
  {
    id: 4,
    title: "Mengumpulkan Tugas Praktikum",
    description: "Memeriksa kembali seluruh file sebelum dikumpulkan.",
    priority: "low",
    deadline: "2026-11-24",
    status: "done",
  },
];

const emptyForm = {
  title: "",
  description: "",
  priority: "medium",
  deadline: "",
  status: "in progress",
};

function formatDate(value) {
  if (!value) return "-";
  return new Date(`${value}T00:00:00`).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

export default function App() {
  const [todos, setTodos] = useState(initialTodos);
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [selectedTodo, setSelectedTodo] = useState(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const filteredTodos = useMemo(() => {
    return todos.filter((todo) => {
      const matchesSearch = todo.title.toLowerCase().includes(search.toLowerCase());
      const matchesFilter = filter === "all" || todo.status === filter;
      return matchesSearch && matchesFilter;
    });
  }, [todos, search, filter]);

  function openAdd() {
    setForm(emptyForm);
    setModal({ type: "add" });
  }

  function openEdit(todo) {
    setForm({
      title: todo.title,
      description: todo.description,
      priority: todo.priority,
      deadline: todo.deadline,
      status: todo.status,
    });
    setModal({ type: "edit", id: todo.id });
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (!form.title.trim()) {
      alert("Judul tugas wajib diisi.");
      return;
    }

    if (modal.type === "add") {
      const newTodo = { id: Date.now(), ...form };
      setTodos((current) => [newTodo, ...current]);
      alert("Tugas berhasil ditambahkan.");
    } else {
      setTodos((current) =>
        current.map((todo) =>
          todo.id === modal.id ? { ...todo, ...form } : todo
        )
      );
      alert("Tugas berhasil diperbarui.");
    }
    setModal(null);
  }

  function deleteTodo(id) {
    const confirmed = window.confirm("Apakah kamu yakin ingin menghapus tugas ini?");
    if (!confirmed) return;
    setTodos((current) => current.filter((todo) => todo.id !== id));
    if (selectedTodo?.id === id) setSelectedTodo(null);
    alert("Tugas berhasil dihapus.");
  }

  function openDetail(todo) {
    setSelectedTodo(todo);
    setModal({ type: "detail" });
  }

  function closeModal() {
    setModal(null);
    setSelectedTodo(null);
  }

  return (
    <main className="page">
      <header className="topbar">
        <div>
          <p className="eyebrow">PRODUCTIVITY APP</p>
          <h1>To-Do List</h1>
          <p className="subtitle">Atur tugas harianmu agar lebih terorganisir.</p>
        </div>
        <button className="primary-btn" onClick={openAdd}>＋ Tambah Todo</button>
      </header>

      <section className="summary-grid">
        <article className="summary-card">
          <span className="summary-icon blue">▤</span>
          <div><p>Total Tugas</p><strong>{todos.length}</strong></div>
        </article>
        <article className="summary-card">
          <span className="summary-icon orange">◷</span>
          <div><p>Dalam Proses</p><strong>{todos.filter(t => t.status === "in progress").length}</strong></div>
        </article>
        <article className="summary-card">
          <span className="summary-icon green">✓</span>
          <div><p>Selesai</p><strong>{todos.filter(t => t.status === "done").length}</strong></div>
        </article>
      </section>

      <section className="list-card">
        <div className="list-heading">
          <div>
            <h2>Daftar Tugas</h2>
            <p>Kelola dan pantau semua pekerjaanmu.</p>
          </div>
          <div className="tools">
            <input
              className="search-input"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari tugas..."
            />
            <select value={filter} onChange={(e) => setFilter(e.target.value)}>
              <option value="all">Semua Status</option>
              <option value="in progress">In Progress</option>
              <option value="done">Done</option>
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Judul</th>
                <th>Status</th>
                <th>Prioritas</th>
                <th>Deadline</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filteredTodos.map((todo) => (
                <tr key={todo.id}>
                  <td>
                    <button className="title-link" onClick={() => openDetail(todo)}>
                      {todo.title}
                    </button>
                    <span className="description-preview">{todo.description}</span>
                  </td>
                  <td><span className={`status ${todo.status === "done" ? "done" : "progress"}`}>{todo.status}</span></td>
                  <td><span className={`priority ${todo.priority}`}>{todo.priority}</span></td>
                  <td>{formatDate(todo.deadline)}</td>
                  <td>
                    <div className="actions">
                      <button className="icon-btn view" title="Lihat detail" onClick={() => openDetail(todo)}>◉</button>
                      <button className="icon-btn edit" title="Edit tugas" onClick={() => openEdit(todo)}>✎</button>
                      <button className="icon-btn delete" title="Hapus tugas" onClick={() => deleteTodo(todo.id)}>⌫</button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredTodos.length === 0 && (
                <tr><td colSpan="5" className="empty">Tidak ada tugas yang ditemukan.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="table-footer">Menampilkan {filteredTodos.length} dari {todos.length} tugas</div>
      </section>

      {modal && modal.type !== "detail" && (
        <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && closeModal()}>
          <form className="modal" onSubmit={handleSubmit}>
            <div className="modal-heading">
              <div>
                <p className="eyebrow">TASK MANAGEMENT</p>
                <h2>{modal.type === "add" ? "Tambah Todo" : "Update Todo"}</h2>
              </div>
              <button type="button" className="close-btn" onClick={closeModal}>×</button>
            </div>

            <label>Judul Tugas
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Masukkan judul tugas" required />
            </label>
            <label>Deskripsi
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Jelaskan tugas..." rows="3" />
            </label>
            <div className="form-row">
              <label>Status
                <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                  <option value="in progress">In Progress</option>
                  <option value="done">Done</option>
                </select>
              </label>
              <label>Prioritas
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </label>
            </div>
            <label>Deadline
              <input type="date" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
            </label>
            <div className="modal-actions">
              <button type="button" className="secondary-btn" onClick={closeModal}>Batal</button>
              <button type="submit" className="primary-btn">{modal.type === "add" ? "Tambah Tugas" : "Simpan Perubahan"}</button>
            </div>
          </form>
        </div>
      )}

      {modal?.type === "detail" && selectedTodo && (
        <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && closeModal()}>
          <section className="modal detail-modal">
            <div className="modal-heading">
              <div><p className="eyebrow">TASK DETAIL</p><h2>Detail Tugas</h2></div>
              <button className="close-btn" onClick={closeModal}>×</button>
            </div>
            <div className="detail-title">{selectedTodo.title}</div>
            <div className="detail-block"><span>Deskripsi</span><p>{selectedTodo.description || "Tidak ada deskripsi."}</p></div>
            <div className="detail-columns">
              <div className="detail-block"><span>Status</span><p>{selectedTodo.status}</p></div>
              <div className="detail-block"><span>Prioritas</span><p>{selectedTodo.priority}</p></div>
              <div className="detail-block"><span>Deadline</span><p>{formatDate(selectedTodo.deadline)}</p></div>
            </div>
            <div className="modal-actions">
              <button className="secondary-btn" onClick={closeModal}>Tutup</button>
              <button className="primary-btn" onClick={() => openEdit(selectedTodo)}>Edit Tugas</button>
            </div>
          </section>
        </div>
      )}
      <footer>To-Do List <span>•</span> React.js Praktikum</footer>
    </main>
  );
}
